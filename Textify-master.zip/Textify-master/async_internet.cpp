#include "stdafx.h"

#ifdef UPDATE_CHECKER

#include "../async_internet.cpp"

#endif
