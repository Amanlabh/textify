# Textify

A small tool which allows to copy text from dialogs and controls which don’t allow it otherwise.

https://ramensoftware.com/textify
