//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Textify.rc
//
#define IDR_MAINFRAME                   128
#define IDD_MAINDLG                     129
#define IDD_TEXTDLG                     201
#define IDD_SETTINGSDLG                 202
#define IDS_MAINDLG_TITLE               203
#define IDS_MAINDLG_HEADER              204
#define IDS_MAINDLG_HOMEPAGE            205
#define IDS_MAINDLG_MOUSE_SHORTCUT      206
#define IDS_MAINDLG_CTRL                207
#define IDS_MAINDLG_ALT                 208
#define IDS_MAINDLG_SHIFT               209
#define IDS_MAINDLG_MOUSE_LEFT          210
#define IDS_MAINDLG_MOUSE_RIGHT         211
#define IDS_MAINDLG_MOUSE_MIDDLE        212
#define IDS_MAINDLG_APPLY               213
#define IDS_MAINDLG_ADVANCED            214
#define IDS_MAINDLG_MORE_SETTINGS       215
#define IDS_MAINDLG_EXIT                216
#define IDS_MAINDLG_WARNING_MODIFIER_TEXT 217
#define IDS_MAINDLG_WARNING_MODIFIER_TITLE 218
#define IDS_SETTINGSDLG_TITLE           219
#define IDS_SETTINGSDLG_OK              220
#define IDS_SETTINGSDLG_CANCEL          221
#define IDS_SETTINGSDLG_WARNING_DISCARD_TEXT 222
#define IDS_SETTINGSDLG_WARNING_DISCARD_TITLE 223
#define IDS_TRAY_TEXTIFY                224
#define IDS_TRAY_EXIT                   225
#define IDS_UPDATE_TEXT                 226
#define IDS_UPDATE_TITLE                227
#define IDS_UPDATE_VERSION_CURRENT      228
#define IDS_UPDATE_VERSION_NEW          229
#define IDS_UPDATE_CHANGELOG            230
#define IDS_UPDATE_UPDATE               231
#define IDS_UPDATE_CLOSE                232
#define IDS_UPDATE_DOWNLOADING          233
#define IDS_UPDATE_ABORT                234
#define IDS_UPDATE_ERROR_DOWNLOAD       235
#define IDS_DEFAULT_TEXT                236
#define IDS_ERROR                       237
#define IDS_ERROR_OPEN_ADDRESS          238
#define IDS_ERROR_EXECUTE               239
#define IDC_MAIN_ICON                   1000
#define IDC_MAIN_SYSLINK                1001
#define IDC_MOUSE_SHORTCUT              1002
#define IDC_CHECK_CTRL                  1003
#define IDC_CHECK_ALT                   1004
#define IDC_CHECK_SHIFT                 1005
#define IDC_COMBO_KEYS                  1006
#define IDC_ADVANCED                    1007
#define IDC_SHOW_INI                    1008
#define IDC_EXIT                        1009
#define IDC_CONFIG_TEXT                 1010
#define IDC_EDIT                        1011
#define IDC_WEB_BUTTON_1                1012

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        240
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
