#pragma once

bool CommandLaunch(const WCHAR* command, const WCHAR* replacement, int width, int height);
