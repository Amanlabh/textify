#pragma once

namespace URLEncoder
{
	CString Encode(const CString& str);
}
